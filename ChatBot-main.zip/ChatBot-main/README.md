# ChatBot
CHATBOT WITH RULE-BASED  RESPONSES  Built a simple chatbot that responds to user inputs based on predefined rules. Use if-else statements or pattern-matching techniques to identify user queries and provide appropriate responses. 



![Screenshot (241)](https://github.com/Rutujaasabe/ChatBot/assets/97525707/078ceba8-30a1-401a-9499-811385351da2)

